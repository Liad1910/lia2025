package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class activity_game extends AppCompatActivity {

    int result;
    int guessCount = 0;

    static int getRandomNumber(int max, int min) {
        return (int) ((Math.random() * (max - min + 1)) + min);
    }

    public void makeToast(String str) {
        Toast.makeText(activity_game.this, str, Toast.LENGTH_SHORT).show();
    }

    public void startGame(View view) {

        EditText variable = (EditText) findViewById(R.id.num1);
        EditText variable1 = (EditText) findViewById(R.id.num2);

        String minStr = variable.getText().toString();
        String maxStr = variable1.getText().toString();

        if (minStr.isEmpty() || maxStr.isEmpty()) {
            makeToast("Please enter both minimum and maximum values!");
            return;
        }

        int min1 = Integer.parseInt(minStr);
        int max = Integer.parseInt(maxStr);

        if (min1 >= max) {
            makeToast("Minimum number should be less than Maximum number!");
        } else {
            result = getRandomNumber(max, min1);
            guessCount = 0;
            makeToast("Game Started! Try guessing the number.");

        }
    }

    public void clickFunction(View view) {

        
        EditText variable = (EditText) findViewById(R.id.editId);
        String guessStr = variable.getText().toString();

        if (guessStr.isEmpty()) {
            makeToast("Please enter a guess!");
            return;
        }

        int userGuessing = Integer.parseInt(guessStr);
        guessCount++;

        if (userGuessing < result) {
            makeToast("Think of a Higher Number, Try Again");
        } else if (userGuessing > result) {
            makeToast("Think of a Lower Number, Try Again");
        } else {
            makeToast("Congratulations, You Got the Number!"+"the guss count is"+guessCount);
        }


    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);



    }
}


