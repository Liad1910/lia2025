package com.example.myapplication;

import static com.example.myapplication.R.id.constraintLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //implements View.OnClickListener
    Button button1;
    Button button2;
    TextView tv1;
Switch switch1;

Button linear;

Button boy;

Button game;

ConstraintLayout constraintLayout;
    ImageView imageView;
    ImageView imageView1;

    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
switch1 = findViewById(R.id.switch1);
switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        if (b){
            constraintLayout.setBackgroundColor(Color.parseColor("#f7b5ed"));
            switch1.setText("on");
        }
        else{
            constraintLayout.setBackgroundColor(Color.parseColor("#e8b5f7"));
            switch1.setText("off");
        }
    }
});

constraintLayout = findViewById(R.id.constraintLayout);



        imageView=findViewById(R.id.imageView);
imageView1=findViewById(R.id.imageView1);

        seekBar=findViewById(R.id.seekBar);
        seekBar.setProgress(100);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                float alpha = (float) i/100;
                imageView.setAlpha(alpha);

                imageView1.setAlpha(1 - alpha);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });
        initViews();


    }

    private void initViews() {
        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "you dumb", Toast.LENGTH_SHORT).show();
            }

        });
        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "YOU SMART", Toast.LENGTH_SHORT).show();
            }

        });
        linear = findViewById(R.id.linear);
        linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, activity_linear.class);
                startActivity(intent);
            }
        });

        boy = findViewById(R.id.boy);
        boy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,activity_boy.class);
                startActivity(intent);


            }
        });
        game=findViewById(R.id.game);
        game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,activity_game.class);
                startActivity(intent);
            }
        });
    }
}




